	
<?php

require('AfricasTalkingGateway.php');
// Reads the variables sent via POST from our gateway
$sessionId   = $_POST["sessionId"];
$serviceCode = $_POST["serviceCode"];
$phoneNumber = $_POST["phoneNumber"];
$text        = $_POST["text"];

if ( $text == "" ) {


		// This is the first request. Note how we start the response with CON
	$response  = "CON Welcome to Cafe shop? \n";
	$response .= "1. Register \n";
	$response .= "2. Menu \n";
	$response .= "3. Promo \n";
	$response .= "4. Feedback \n";
	$response .= "5. Outlets \n";


} else if ( $text == "1" ) {
		

	//registration of users

} else if ( $text == "2" ) {
	$response  = "CON Menu \n";
	$response .= "1. coffee \n";
	$response .= "2. Tea \n";

			if ( $text == "1"){
			$response  = "CON Coffee \n";
			$response .= "1. cafe mocha \n";
			$response .= "2. Expresso \n";
			$response .= "3. Expresso \n";
			}




}else if ( $text == "3" ) {

	$response  = "CON Promo \n";
	$response .= "Get Promotion item update send activate to 123   \n";

}else if ( $text == "4" ) {

	$response  = "CON Feedback \n";
	$response .= "Did you enjoy our services\n";
}else if ( $text == "5" ) {

	$response  = "CON Outlets \n";
	$response .= "Main branch Nairobi house\n";
}





// Print the response onto the page so that our gateway can read it
header('Content-type: text/plain');
echo $response;

// DONE!!!
?>

