<html>
	<head>
	Pesapi
	</head>
	<body>
		Please register for the Pesa PI</br>
		<form method="post" action="buy.php">
		Name: <input type="text" name="name" value=""><br>
		Phone:<input type="text" name="phone" value=""><br>
		      <input type="submit" name="pay" value="Pay Now"><br>
		
		</form>
	</body>
</html>


